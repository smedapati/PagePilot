import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import confluence_sync as cs  # noqa: E402


# --------------------------------------------------------------------------- #
# In-memory fake of the parts of the Confluence API the script uses
# --------------------------------------------------------------------------- #
class FakeConfluence:
    def __init__(self):
        self.pages = {}
        self.next_id = 100
        self.calls = []

    def _view(self, p):
        return {
            "id": p["id"], "title": p["title"],
            "version": {"number": p["version"], "message": p["message"]},
            "ancestors": self._ancestors(p),
            "metadata": {"labels": {"results": [{"name": lb} for lb in sorted(p["labels"])]}},
        }

    def _ancestors(self, p):
        # Confluence returns the full chain, root first.
        chain, parent = [], p["parent"]
        while parent:
            chain.insert(0, {"id": parent})
            parent = self.pages[parent]["parent"] if parent in self.pages else None
        return chain

    def iter_managed(self, space, label):
        return [self._view(p) for p in self.pages.values() if label in p["labels"]]

    def find_by_title(self, space, title):
        return next((self._view(p) for p in self.pages.values() if p["title"] == title), None)

    def create_page(self, space, title, storage, parent_id, labels, message):
        self.calls.append(("create", title))
        pid = str(self.next_id)
        self.next_id += 1
        self.pages[pid] = dict(id=pid, title=title, body=storage, parent=parent_id,
                               labels=set(labels), version=1, message=message, attachments={})
        return {"id": pid}

    def update_page(self, page_id, space, title, storage, parent_id, current_version, message):
        self.calls.append(("update", title))
        p = self.pages[page_id]
        assert current_version == p["version"]
        p.update(title=title, body=storage, parent=parent_id,
                 version=current_version + 1, message=message)
        return {"id": page_id}

    def add_labels(self, page_id, labels):
        self.pages[page_id]["labels"].update(labels)

    def upload_attachment(self, page_id, name, path):
        self.calls.append(("attach", name))
        self.pages[page_id]["attachments"][name] = path.read_bytes()

    def delete_page(self, page_id):
        self.calls.append(("delete", self.pages[page_id]["title"]))
        del self.pages[page_id]

    def by_title(self, title):
        return next(p for p in self.pages.values() if p["title"] == title)


def make_cfg(root: Path, **overrides) -> cs.Config:
    base = dict(
        docs_dir=root / "docs", repo_root=root, base_url="https://x", user=None, token="t",
        space_key="ENG", parent_id="1", title_prefix="", excludes=[], namespace="group/repo",
        adopt_existing=False, verify_ssl=True, banner=False, project_url=None, branch=None,
        commit_sha="abcdef123456",
    )
    base.update(overrides)
    return cs.Config(**base)


def write(root: Path, rel: str, text: str | bytes) -> Path:
    p = root / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(text, bytes):
        p.write_bytes(text)
    else:
        p.write_text(text, encoding="utf-8")
    return p


def run(cfg, client, **kw):
    nodes = cs.build_plan(cfg)
    warnings = cs.render_plan(nodes, cfg)
    return cs.sync(nodes, client, cfg, **kw), warnings


@pytest.fixture
def repo(tmp_path):
    write(tmp_path, "docs/getting-started.md", "# Getting Started\n\nSee [setup](guides/setup.md).\n")
    write(tmp_path, "docs/guides/README.md", "# Guides\n\nAll the guides.\n")
    write(tmp_path, "docs/guides/setup.md", "# Setup\n\n![diagram](img/arch.png)\n")
    write(tmp_path, "docs/guides/img/arch.png", b"\x89PNG fake")
    write(tmp_path, "docs/reference/api_tokens.md", "Tokens are rotated monthly.\n")
    return tmp_path


# --------------------------------------------------------------------------- #
# Sync behaviour
# --------------------------------------------------------------------------- #
def actions(outcomes):
    return {o.title: o.action for o in outcomes}


def test_first_run_creates_hierarchy(repo):
    fc, cfg = FakeConfluence(), make_cfg(repo)
    outcomes, warnings = run(cfg, fc)

    assert warnings == []
    assert set(actions(outcomes).values()) == {"created"}
    assert set(actions(outcomes)) == {"Getting Started", "Guides", "Setup", "Reference", "Api Tokens"}
    # README.md became the folder page; children hang under it; top level under parent 1.
    assert fc.by_title("Setup")["parent"] == fc.by_title("Guides")["id"]
    assert fc.by_title("Api Tokens")["parent"] == fc.by_title("Reference")["id"]
    assert fc.by_title("Getting Started")["parent"] == "1"
    assert "children" in fc.by_title("Reference")["body"]          # generated folder index
    assert fc.by_title("Setup")["attachments"] == {"arch.png": b"\x89PNG fake"}
    assert 'ri:filename="arch.png"' in fc.by_title("Setup")["body"]
    assert 'ri:content-title="Setup"' in fc.by_title("Getting Started")["body"]


def test_second_run_is_noop(repo):
    fc, cfg = FakeConfluence(), make_cfg(repo)
    run(cfg, fc)
    fc.calls.clear()
    outcomes, _ = run(cfg, fc)
    assert set(actions(outcomes).values()) == {"unchanged"}
    assert fc.calls == []


def test_edit_updates_only_that_page(repo):
    fc, cfg = FakeConfluence(), make_cfg(repo)
    run(cfg, fc)
    page_id = fc.by_title("Setup")["id"]
    write(repo, "docs/guides/setup.md", "# Setup\n\nNow with more steps.\n")
    fc.calls.clear()

    outcomes, _ = run(cfg, fc)
    assert [o.title for o in outcomes if o.action == "updated"] == ["Setup"]
    page = fc.by_title("Setup")
    assert page["id"] == page_id and page["version"] == 2
    assert "more steps" in page["body"]


def test_changed_image_triggers_update(repo):
    fc, cfg = FakeConfluence(), make_cfg(repo)
    run(cfg, fc)
    write(repo, "docs/guides/img/arch.png", b"\x89PNG v2")
    outcomes, _ = run(cfg, fc)
    assert actions(outcomes)["Setup"] == "updated"
    assert fc.by_title("Setup")["attachments"]["arch.png"] == b"\x89PNG v2"


def test_title_change_keeps_same_page(repo):
    fc, cfg = FakeConfluence(), make_cfg(repo)
    run(cfg, fc)
    old_id = fc.by_title("Setup")["id"]
    write(repo, "docs/guides/setup.md", "# Environment Setup\n\nBody.\n")
    run(cfg, fc)
    assert fc.by_title("Environment Setup")["id"] == old_id


def test_prune_only_when_asked(repo):
    fc, cfg = FakeConfluence(), make_cfg(repo)
    run(cfg, fc)
    (repo / "docs/reference/api_tokens.md").unlink()

    run(cfg, fc)                                  # no prune: pages stay
    assert any(p["title"] == "Api Tokens" for p in fc.pages.values())

    outcomes, _ = run(cfg, fc, prune=True)
    deleted = [o.title for o in outcomes if o.action == "deleted"]
    assert set(deleted) == {"Api Tokens", "Reference"}
    assert deleted.index("Api Tokens") < deleted.index("Reference")   # children first


def test_dry_run_writes_nothing(repo):
    fc, cfg = FakeConfluence(), make_cfg(repo)
    outcomes, _ = run(cfg, fc, dry_run=True)
    assert set(actions(outcomes).values()) == {"created"}
    assert fc.pages == {} and fc.calls == []


def test_refuses_to_overwrite_foreign_page(repo):
    fc, cfg = FakeConfluence(), make_cfg(repo)
    fc.create_page("ENG", "Setup", "<p>hand written</p>", None, ["unrelated"], "x")
    outcomes, _ = run(cfg, fc)
    assert actions(outcomes)["Setup"] == "failed"
    assert fc.by_title("Setup")["body"] == "<p>hand written</p>"

    fc2 = FakeConfluence()
    fc2.create_page("ENG", "Setup", "<p>hand written</p>", None, ["unrelated"], "x")
    outcomes, _ = run(make_cfg(repo, adopt_existing=True), fc2)
    assert actions(outcomes)["Setup"] == "updated"


def test_failed_parent_skips_children(repo):
    class Flaky(FakeConfluence):
        def create_page(self, space, title, *a, **k):
            if title == "Guides":
                raise cs.ConfluenceError("boom", 500)
            return super().create_page(space, title, *a, **k)

    outcomes, _ = run(make_cfg(repo), Flaky())
    acts = actions(outcomes)
    assert acts["Guides"] == "failed" and acts["Setup"] == "skipped"
    assert acts["Getting Started"] == "created"


# --------------------------------------------------------------------------- #
# Planning and conversion
# --------------------------------------------------------------------------- #
def test_duplicate_titles_fail_fast(tmp_path):
    write(tmp_path, "docs/a/overview.md", "# Overview\n")
    write(tmp_path, "docs/b/overview.md", "# Overview\n")
    with pytest.raises(cs.PlanError, match="Duplicate page titles"):
        cs.build_plan(make_cfg(tmp_path))


def test_front_matter_title_and_publish_false(tmp_path):
    write(tmp_path, "docs/a.md", "---\ntitle: Custom Title\n---\n# Heading Stays\n\nText\n")
    write(tmp_path, "docs/draft.md", "---\npublish: false\n---\n# Draft\n")
    nodes = cs.build_plan(make_cfg(tmp_path))
    assert [n.title for n in nodes] == ["Custom Title"]
    assert "Heading Stays" in nodes[0].body_md      # differs from title, so kept


def test_title_prefix_and_excludes(tmp_path):
    write(tmp_path, "docs/a.md", "# A\n")
    write(tmp_path, "docs/drafts/b.md", "# B\n")
    nodes = cs.build_plan(make_cfg(tmp_path, title_prefix="[Pay] ", excludes=["drafts/*"]))
    assert [n.title for n in nodes] == ["[Pay] A"]


def render(md, tmp_path=None, files=None):
    root = tmp_path or Path("/nonexistent")
    return cs.Renderer(root / "docs", root, files or {}).render(md, "page.md")


def test_code_block_becomes_macro():
    r = render("```python\nif a < b and x]]>y:\n    pass\n```\n")
    assert '<ac:parameter ac:name="language">py</ac:parameter>' in r.storage
    assert "if a < b and x]]]]><![CDATA[>y:\n    pass]]>" in r.storage
    assert cs.check_xhtml(r.storage) is None


def test_tables_entities_and_alerts_are_valid_xhtml():
    md = ("| A | B |\n|---|---|\n| 1&nbsp;2 | <br> |\n\n"
          "> [!WARNING]\n> Do not run this in prod.\n")
    r = render(md)
    assert "<table>" in r.storage
    assert "&nbsp;" not in r.storage and "&#160;" in r.storage
    assert 'ac:name="warning"' in r.storage and "Do not run this in prod." in r.storage
    assert cs.check_xhtml(r.storage) is None


def test_external_links_untouched_and_broken_links_warned(tmp_path):
    (tmp_path / "docs").mkdir()
    r = render("[ext](https://example.com) [anchor](#top) [missing](nope.md) ![x](gone.png)", tmp_path)
    assert 'href="https://example.com"' in r.storage and 'href="#top"' in r.storage
    assert len(r.warnings) == 2


def test_links_cannot_escape_repo(tmp_path):
    write(tmp_path.parent, "secret.txt", "s3cret")
    (tmp_path / "docs").mkdir()
    r = render("[x](../../secret.txt)", tmp_path)
    assert r.attachments == {}

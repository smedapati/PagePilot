# Database Failover

1. Confirm replica lag is under 5s.
2. Promote the replica:

   ```sql
   EXEC sp_failover @target = 'replica-2';
   ```

> [!WARNING]
> Never fail over during the nightly batch window.

---
title: Local Environment Setup
---
# Local Environment Setup

![Architecture](img/architecture.png)

| Tool   | Version |
|--------|---------|
| Python | 3.12    |
| Docker | 27+     |

```bash
make bootstrap && make test
```

Line one<br>line two.
